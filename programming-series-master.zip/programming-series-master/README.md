# Programming for Data Science (Free education in Burmese Language by Myanmar Data Science)
<p>This repository includes the exercise files from our course "Programming for Data Science" series which can be found at https://www.youtube.com/watch?v=jOZNjVVZIVs&list=PLD_eiqVVLZDi9GZZJDC8Zx4-3Np8LHs52 </p>
<p>For all the lab session to practice along, please refer to the Lab sessions playlist at https://www.youtube.com/watch?v=FXPPJCnuJuE&list=PLD_eiqVVLZDh0FDc1UwCUCFsNMKlxOiv3 </p>
